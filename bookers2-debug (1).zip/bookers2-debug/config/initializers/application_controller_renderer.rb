# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '8b590a0e98b99f8d11d07aaaf8472e265a023748b8249faded442bf3bd9ab89dca35f6b5dc2d6713e9e40ac902e1b406a8ab09c61bf10b5ceb23f5e3f5c9a3a3'
